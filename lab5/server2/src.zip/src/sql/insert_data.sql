INSERT INTO patient (name, dateOfBirth) 
VALUES
  ("Kratos", "2005-03-22"),
  ("Nathan Drake", "2007-10-13"),
  ("Cole MacGrath", "2009-11-01"),
  ("Ratchet", "2002-11-04");