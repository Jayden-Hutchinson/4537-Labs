export const BASE_URL = "https://comp4537-lab4-asphp.ondigitalocean.app";
export const ENDPOINT = "/api/definitions";

export const FULL_URL = `${BASE_URL}${ENDPOINT}`;
