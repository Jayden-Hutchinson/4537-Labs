export const BASE_URL = "http://localhost:3000";
export const ENDPOINT = "/api/definitions";

export const FULL_URL = `${BASE_URL}${ENDPOINT}`;
